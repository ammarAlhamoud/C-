﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MonopolyGameModel.Model
{
    public abstract class  AIPlayer: APlayer
    {
    }
}
