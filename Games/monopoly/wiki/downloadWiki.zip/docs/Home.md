**Project Description**
The project is an implementation of the monopoly game, with multi-player and multi-platform support.
The monopoly project is intended for educational purposes - specifically for academic purposes.
This project will show use of WCF, XNA, technologies, and good design patterns and software engineering methods.
This project was created as part of academic requirements  of Tel-Aviv Yaffo College , CS Department ([http://www.mta.ac.il](http://www.mta.ac.il))
